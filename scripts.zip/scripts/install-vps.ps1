﻿#Requires -Version 5.1
<#
.SYNOPSIS
  AccelaNova Windows VPS bare-metal installer / updater.
.DESCRIPTION
  Implements BARE_METAL.md production flow with VPS occupancy checks so AccelaNova
  coexists with IIS, nginx, Apache, and other Node apps. Never kills processes outside
  InstallDir. Never stops IIS/nginx/Apache. Default: no firewall changes for 80/443.
.PARAMETER Mode
  install | update | start | stop | scan
.NOTES
  Keep this file beside install-vps.bat. The .bat is the only entry point operators run.
#>
[CmdletBinding()]
param(
    [ValidateSet('install', 'update', 'start', 'stop', 'scan')]
    [string]$Mode = 'install',

    [string]$RepoUrl = 'https://github.com/BQI-TECH/AccelaNova.git',
    [string]$RepoBranch = 'main',
    [string]$InstallDir = 'C:\Accelanova',
    [int]$ServerPort = 3001,
    [int]$CollectorPort = 8888,
    [string]$ViteApiBase = '/api',
    [int]$MinNodeMajor = 18,

    # true/false strings are safe from cmd.exe (avoid [bool]/[switch] from .bat).
    [string]$CloneIfMissing = 'true',
    [string]$SkipClone = 'false',
    [string]$InstallDeps = 'true',
    [string]$BuildFrontend = 'true',
    [string]$RunMigrations = 'true',
    [string]$StartAfterInstall = 'true',
    [string]$ExposeFirewall = 'false',
    [string]$InstallAsService = 'false',
    [string]$Yes = 'false',

    [string]$NssmPath = 'C:\Tools\nssm\nssm.exe',
    [string]$ServiceName = 'Accelanova',
    [string]$ServiceDisplay = 'Accelanova AI Server'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function ConvertTo-BoolFlag([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return $false }
    return @('1', 'true', 'yes', 'y', 'on') -contains ($Value.Trim().ToLowerInvariant())
}

# Convert bat-passed "true"/"false" strings once; never use [switch]/[bool] from cmd.exe.
$script:Flags = @{
    CloneIfMissing    = ConvertTo-BoolFlag $CloneIfMissing
    SkipClone         = ConvertTo-BoolFlag $SkipClone
    InstallDeps       = ConvertTo-BoolFlag $InstallDeps
    BuildFrontend     = ConvertTo-BoolFlag $BuildFrontend
    RunMigrations     = ConvertTo-BoolFlag $RunMigrations
    StartAfterInstall = ConvertTo-BoolFlag $StartAfterInstall
    ExposeFirewall    = ConvertTo-BoolFlag $ExposeFirewall
    InstallAsService  = ConvertTo-BoolFlag $InstallAsService
    Yes               = ConvertTo-BoolFlag $Yes
}

$script:ChosenServerPort = $ServerPort
$script:ChosenCollectorPort = $CollectorPort
$script:OtherAppsFound = $false
$script:PortConflictResolved = $false

$LogDirCandidate = Join-Path $InstallDir 'logs'
try {
    New-Item -ItemType Directory -Force -Path $LogDirCandidate -ErrorAction Stop | Out-Null
    $LogDir = $LogDirCandidate
}
catch {
    $LogDir = Join-Path $env:TEMP 'Accelanova-install-logs'
    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
}

$RunStamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
$LogFile = Join-Path $LogDir "install-$RunStamp.log"

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'STEP')][string]$Level = 'INFO'
    )
    $line = "[$(Get-Date -Format 'HH:mm:ss')] [$Level] $Message"
    try { Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue } catch { }
    switch ($Level) {
        'ERROR' { Write-Host $line -ForegroundColor Red }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'STEP'  { Write-Host "`n>> $Message" -ForegroundColor Cyan }
        default { Write-Host $line -ForegroundColor DarkGray }
    }
}

function Test-Command {
    param([string]$Name)
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Get-ExitCode {
    if (Test-Path variable:global:LASTEXITCODE) {
        return [int]$global:LASTEXITCODE
    }
    return 0
}

function Invoke-Logged {
    param([string]$WorkDir, [string[]]$Command)
    if (-not $Command -or $Command.Count -lt 1) { throw 'Invoke-Logged requires a command' }
    Push-Location $WorkDir
    try {
        Write-Log ("Running in {0}: {1}" -f $WorkDir, ($Command -join ' '))
        if ($Command.Count -eq 1) {
            & $Command[0] 2>&1 | Tee-Object -FilePath $LogFile -Append | Out-Null
        }
        else {
            & $Command[0] $Command[1..($Command.Count - 1)] 2>&1 | Tee-Object -FilePath $LogFile -Append | Out-Null
        }
        $code = Get-ExitCode
        if ($code -ne 0) { throw "Command failed with exit code $code" }
    }
    finally {
        Pop-Location
    }
}

function Set-EnvKey {
    param([string]$Path, [string]$Key, [string]$Value)
    if (-not (Test-Path $Path)) { return }
    $lines = Get-Content $Path
    $out = @()
    $done = $false
    foreach ($line in $lines) {
        if ($line -match ("^\s*#?\s*" + [regex]::Escape($Key) + "\s*=")) {
            $out += ($Key + '="' + $Value + '"')
            $done = $true
        }
        else {
            $out += $line
        }
    }
    if (-not $done) { $out += ($Key + '="' + $Value + '"') }
    Set-Content -Path $Path -Value $out -Encoding UTF8
}

function Test-PathUnderInstall {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    try {
        $full = [System.IO.Path]::GetFullPath($Path)
        $root = [System.IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
        return $full.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)
    }
    catch {
        return $false
    }
}

function Get-ProcessPathSafe {
    param([int]$ProcessId)
    try {
        $p = Get-Process -Id $ProcessId -ErrorAction Stop
        if ($p.Path) { return $p.Path }
    }
    catch { }
    try {
        $cim = Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId" -ErrorAction SilentlyContinue
        if ($cim -and $cim.ExecutablePath) { return $cim.ExecutablePath }
        if ($cim -and $cim.CommandLine) { return $cim.CommandLine }
    }
    catch { }
    return ''
}

function Get-ListeningPortMap {
    $map = @{}
    try {
        $conns = Get-NetTCPConnection -State Listen -ErrorAction Stop
        foreach ($c in $conns) {
            $port = [int]$c.LocalPort
            if (-not $map.ContainsKey($port)) {
                $map[$port] = [System.Collections.Generic.List[object]]::new()
            }
            $map[$port].Add([pscustomobject]@{
                Pid  = [int]$c.OwningProcess
                Addr = $c.LocalAddress
            })
        }
    }
    catch {
        Write-Log 'Get-NetTCPConnection unavailable; falling back to netstat' 'WARN'
        $raw = netstat -ano -p tcp 2>$null
        foreach ($line in $raw) {
            if ($line -notmatch 'LISTENING') { continue }
            $parts = ($line -split '\s+') | Where-Object { $_ -ne '' }
            if ($parts.Count -lt 5) { continue }
            $local = $parts[1]
            $procId = 0
            [void][int]::TryParse($parts[-1], [ref]$procId)
            if ($local -match ':(\d+)$') {
                $port = [int]$Matches[1]
                if (-not $map.ContainsKey($port)) {
                    $map[$port] = [System.Collections.Generic.List[object]]::new()
                }
                $map[$port].Add([pscustomobject]@{ Pid = $procId; Addr = $local })
            }
        }
    }
    return $map
}

function Get-ServicePresence {
    $names = @('W3SVC', 'WAS', 'IISADMIN', 'nginx', 'Apache2.4', 'httpd', 'Apache')
    $found = @()
    foreach ($n in $names) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc) {
            $found += [pscustomobject]@{
                Name   = $svc.Name
                Status = $svc.Status.ToString()
                DisplayName = $svc.DisplayName
            }
        }
    }
    # nginx/Apache often run as plain processes without a Windows service of that name
    foreach ($procName in @('nginx', 'httpd', 'apache', 'apache2')) {
        Get-Process -Name $procName -ErrorAction SilentlyContinue | ForEach-Object {
            $found += [pscustomobject]@{
                Name        = $procName
                Status      = 'Running(process)'
                DisplayName = $_.Path
            }
        }
    }
    return $found
}

function Test-OwnerIsAccelanova {
    param([int]$ProcessId, [string]$PathOrCmd)
    if (Test-PathUnderInstall $PathOrCmd) { return $true }
    try {
        $cim = Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId" -ErrorAction SilentlyContinue
        if ($cim -and $cim.CommandLine -and ($cim.CommandLine -like "*$InstallDir*")) {
            return $true
        }
    }
    catch { }
    return $false
}

function Find-NextFreePort {
    param(
        [int]$Preferred,
        [hashtable]$ListenMap,
        [int[]]$AlsoAvoid = @()
    )
    $candidates = @($Preferred)
    for ($i = 1; $i -le 20; $i++) { $candidates += ($Preferred + $i) }
    if ($Preferred -eq 3001) {
        $candidates += @(3010, 3011, 3020, 3101, 3200)
    }
    elseif ($Preferred -eq 8888) {
        $candidates += @(8889, 8890, 8988, 9000)
    }

    foreach ($p in ($candidates | Select-Object -Unique)) {
        if ($AlsoAvoid -contains $p) { continue }
        $inUse = $ListenMap.ContainsKey($p)
        if (-not $inUse) { return $p }
        # Allow reuse if every listener belongs to AccelaNova under InstallDir
        $allOurs = $true
        foreach ($owner in $ListenMap[$p]) {
            $path = Get-ProcessPathSafe -ProcessId $owner.Pid
            if (-not (Test-OwnerIsAccelanova -ProcessId $owner.Pid -PathOrCmd $path)) {
                $allOurs = $false
                break
            }
        }
        if ($allOurs) { return $p }
    }
    throw "No free TCP port near $Preferred"
}

function Show-VpsOccupancyReport {
    Write-Log 'VPS occupancy report' 'STEP'
    Write-Host ''
    Write-Host '========== VPS OCCUPANCY REPORT ==========' -ForegroundColor Cyan

    $listenMap = Get-ListeningPortMap
    $watchPorts = @(80, 443, 3000, 3001, 8080, 8888, $ServerPort, $CollectorPort) |
        Select-Object -Unique |
        Sort-Object

    $rows = @()
    foreach ($port in $watchPorts) {
        if (-not $listenMap.ContainsKey($port)) {
            $rows += [pscustomobject]@{
                Port    = $port
                Status  = 'FREE'
                Pid     = ''
                Process = ''
                Path    = ''
                Ours    = ''
            }
            continue
        }
        $seen = @{}
        foreach ($owner in $listenMap[$port]) {
            if ($seen.ContainsKey($owner.Pid)) { continue }
            $seen[$owner.Pid] = $true
            $procName = ''
            try { $procName = (Get-Process -Id $owner.Pid -ErrorAction SilentlyContinue).ProcessName } catch { }
            $path = Get-ProcessPathSafe -ProcessId $owner.Pid
            $ours = Test-OwnerIsAccelanova -ProcessId $owner.Pid -PathOrCmd $path
            if (-not $ours) { $script:OtherAppsFound = $true }
            $rows += [pscustomobject]@{
                Port    = $port
                Status  = 'IN USE'
                Pid     = $owner.Pid
                Process = $procName
                Path    = $path
                Ours    = $(if ($ours) { 'Accelanova' } else { 'OTHER' })
            }
        }
    }

    $rows | Format-Table -AutoSize | Out-String | ForEach-Object {
        Write-Host $_
        Add-Content -Path $LogFile -Value $_ -ErrorAction SilentlyContinue
    }

    $services = Get-ServicePresence
    if ($services.Count -gt 0) {
        Write-Host 'Web-related services / processes:' -ForegroundColor Yellow
        $script:OtherAppsFound = $true
        foreach ($s in $services) {
            $line = "  - $($s.Name) [$($s.Status)] $($s.DisplayName)"
            Write-Host $line
            Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue
        }
    }
    else {
        Write-Host 'No IIS/nginx/Apache services detected by name.' -ForegroundColor DarkGray
    }

    # Foreign node.exe (not under InstallDir)
    $foreignNode = @()
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
        if (-not (Test-OwnerIsAccelanova -ProcessId $_.ProcessId -PathOrCmd $_.CommandLine)) {
            $foreignNode += $_
            $script:OtherAppsFound = $true
        }
    }
    if ($foreignNode.Count -gt 0) {
        Write-Host "Other Node.js processes (outside $InstallDir):" -ForegroundColor Yellow
        foreach ($n in $foreignNode) {
            $clip = if ($n.CommandLine.Length -gt 120) { $n.CommandLine.Substring(0, 120) + '...' } else { $n.CommandLine }
            $line = "  - PID $($n.ProcessId): $clip"
            Write-Host $line
            Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue
        }
    }
    else {
        Write-Host "No foreign Node.js processes outside $InstallDir." -ForegroundColor DarkGray
    }

    Write-Host 'Safety policy:' -ForegroundColor Cyan
    Write-Host '  - Will NOT kill processes outside InstallDir'
    Write-Host '  - Will NOT stop IIS / nginx / Apache / other services'
    Write-Host '  - Firewall: EXPOSE_FIREWALL defaults off (will not claim 80/443)'
    Write-Host '=========================================='
    Write-Host ''

    return $listenMap
}

function Resolve-PortsSafely {
    param([hashtable]$ListenMap)

    $serverOwnerForeign = $false
    if ($ListenMap.ContainsKey($ServerPort)) {
        foreach ($owner in $ListenMap[$ServerPort]) {
            $path = Get-ProcessPathSafe -ProcessId $owner.Pid
            if (-not (Test-OwnerIsAccelanova -ProcessId $owner.Pid -PathOrCmd $path)) {
                $serverOwnerForeign = $true
                break
            }
        }
    }

    $collectorOwnerForeign = $false
    if ($ListenMap.ContainsKey($CollectorPort)) {
        foreach ($owner in $ListenMap[$CollectorPort]) {
            $path = Get-ProcessPathSafe -ProcessId $owner.Pid
            if (-not (Test-OwnerIsAccelanova -ProcessId $owner.Pid -PathOrCmd $path)) {
                $collectorOwnerForeign = $true
                break
            }
        }
    }

    if ($serverOwnerForeign) {
        $script:ChosenServerPort = Find-NextFreePort -Preferred $ServerPort -ListenMap $ListenMap
        Write-Log "SERVER_PORT $ServerPort is used by another app - using $($script:ChosenServerPort) instead" 'WARN'
        $script:PortConflictResolved = $true
    }
    else {
        $script:ChosenServerPort = $ServerPort
    }

    $avoid = @($script:ChosenServerPort)
    if ($collectorOwnerForeign -or ($script:ChosenServerPort -eq $CollectorPort)) {
        $script:ChosenCollectorPort = Find-NextFreePort -Preferred $CollectorPort -ListenMap $ListenMap -AlsoAvoid $avoid
        if ($script:ChosenCollectorPort -ne $CollectorPort) {
            Write-Log "COLLECTOR_PORT $CollectorPort unavailable - using $($script:ChosenCollectorPort) instead" 'WARN'
            $script:PortConflictResolved = $true
        }
    }
    else {
        $script:ChosenCollectorPort = $CollectorPort
    }

    Save-ChosenPorts
}

function Save-ChosenPorts {
    $portFile = Join-Path $InstallDir 'logs\chosen-ports.json'
    try {
        New-Item -ItemType Directory -Force -Path (Split-Path $portFile) | Out-Null
        @{
            ServerPort    = $script:ChosenServerPort
            CollectorPort = $script:ChosenCollectorPort
            UpdatedAt     = (Get-Date).ToString('o')
        } | ConvertTo-Json | Set-Content -Path $portFile -Encoding UTF8
    }
    catch {
        Write-Log "Could not write chosen-ports.json: $($_.Exception.Message)" 'WARN'
    }
}

function Confirm-ContinueIfBusy {
    if (-not $script:OtherAppsFound -and -not $script:PortConflictResolved) { return }
    if ($script:Flags.Yes) {
        Write-Log 'Other apps detected; continuing because -Yes was passed' 'WARN'
        return
    }
    Write-Host ''
    Write-Host 'Other applications are present on this VPS (see report above).' -ForegroundColor Yellow
    Write-Host 'AccelaNova will NOT stop them. Ports may have been remapped.' -ForegroundColor Yellow
    $answer = Read-Host 'Continue? [Y/N]'
    if ($answer -notmatch '^(Y|y|Yes|yes)$') {
        throw 'Aborted by operator (other apps present). Re-run with /Y to skip this prompt.'
    }
}

function Read-SavedPorts {
    $portFile = Join-Path $InstallDir 'logs\chosen-ports.json'
    if (Test-Path $portFile) {
        try {
            $j = Get-Content $portFile -Raw | ConvertFrom-Json
            if ($j.ServerPort) { $script:ChosenServerPort = [int]$j.ServerPort }
            if ($j.CollectorPort) { $script:ChosenCollectorPort = [int]$j.CollectorPort }
        }
        catch { }
    }
}

function Stop-AccelanovaProcesses {
    Write-Log "Stopping AccelaNova node processes under $InstallDir only" 'STEP'
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -and ($_.CommandLine -like "*$InstallDir*") } |
        ForEach-Object {
            Write-Log "Stopping AccelaNova node PID $($_.ProcessId)"
            Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
        }
}

function Test-Prerequisites {
    Write-Log 'Checking prerequisites' 'STEP'

    if (-not (Test-Command git)) {
        throw 'Git is not installed. Install with: winget install Git.Git'
    }
    Write-Log ("Found " + (git --version))

    if (-not (Test-Command node)) {
        throw 'Node.js is not installed. Install with: winget install OpenJS.NodeJS.LTS'
    }
    $nodeVersion = (node --version) -replace '^v', ''
    $nodeMajor = [int]($nodeVersion.Split('.')[0])
    if ($nodeMajor -lt $MinNodeMajor) {
        throw "Node $MinNodeMajor+ required; found v$nodeVersion"
    }
    Write-Log "Found Node v$nodeVersion"

    if (-not (Test-Command yarn)) {
        Write-Log 'Yarn not found; enabling corepack...' 'WARN'
        corepack enable 2>&1 | Out-Null
        corepack prepare yarn@stable --activate 2>&1 | Out-Null
    }
    if (-not (Test-Command yarn)) {
        throw 'Yarn is required. Install with: npm install -g yarn'
    }
    Write-Log ("Found Yarn " + (yarn --version))
}

function Initialize-Repository {
    Write-Log 'Preparing install directory' 'STEP'

    if ($script:Flags.SkipClone) {
        if (-not (Test-Path (Join-Path $InstallDir '.git'))) {
            throw "SkipClone set but $InstallDir is not a git repository"
        }
        return
    }

    if (Test-Path (Join-Path $InstallDir '.git')) {
        Write-Log "Repository already exists at $InstallDir - skipping clone" 'WARN'
        return
    }

    if (-not $script:Flags.CloneIfMissing) {
        throw "Install directory missing and CloneIfMissing not set"
    }

    Write-Log "Cloning $RepoUrl (branch $RepoBranch)" 'STEP'
    $parent = Split-Path $InstallDir -Parent
    if ($parent) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    git clone --branch $RepoBranch --single-branch $RepoUrl $InstallDir 2>&1 | Tee-Object -FilePath $LogFile -Append | Out-Null
    if ((Get-ExitCode) -ne 0) { throw 'git clone failed' }
}

function Update-Repository {
    Write-Log 'Updating repository' 'STEP'
    if (-not (Test-Path (Join-Path $InstallDir '.git'))) {
        throw "No git repo at $InstallDir. Run install mode first."
    }

    Stop-AccelanovaProcesses

    Push-Location $InstallDir
    try {
        git fetch origin $RepoBranch 2>&1 | Tee-Object -FilePath $LogFile -Append | Out-Null
        if ((Get-ExitCode) -ne 0) { throw 'git fetch failed' }
        git checkout $RepoBranch 2>&1 | Tee-Object -FilePath $LogFile -Append | Out-Null
        git pull origin $RepoBranch 2>&1 | Tee-Object -FilePath $LogFile -Append | Out-Null
        if ((Get-ExitCode) -ne 0) { throw 'git pull failed' }
        $head = git log -1 --pretty=format:'%h'
        Write-Log "HEAD is now $head"
    }
    finally {
        Pop-Location
    }
}

function Initialize-EnvFiles {
    Write-Log 'Setting up environment files' 'STEP'

    $serverEnv = Join-Path $InstallDir 'server\.env'
    $frontendEnv = Join-Path $InstallDir 'frontend\.env'
    $collectorEnv = Join-Path $InstallDir 'collector\.env'
    $storageDir = Join-Path $InstallDir 'server\storage'

    if (-not (Test-Path $serverEnv)) {
        Copy-Item (Join-Path $InstallDir 'server\.env.example') $serverEnv
        Write-Log 'Created server\.env from example'
    }
    else {
        Write-Log 'server\.env already exists - updating ports/STORAGE_DIR only'
    }

    if (-not (Test-Path $frontendEnv) -and (Test-Path (Join-Path $InstallDir 'frontend\.env.example'))) {
        Copy-Item (Join-Path $InstallDir 'frontend\.env.example') $frontendEnv
        Write-Log 'Created frontend\.env from example'
    }

    if (-not (Test-Path $collectorEnv) -and (Test-Path (Join-Path $InstallDir 'collector\.env.example'))) {
        Copy-Item (Join-Path $InstallDir 'collector\.env.example') $collectorEnv
        Write-Log 'Created collector\.env from example'
    }

    Set-EnvKey -Path $serverEnv -Key 'STORAGE_DIR' -Value $storageDir
    Set-EnvKey -Path $serverEnv -Key 'SERVER_PORT' -Value "$($script:ChosenServerPort)"
    Set-EnvKey -Path $frontendEnv -Key 'VITE_API_BASE' -Value $ViteApiBase
    if (Test-Path $collectorEnv) {
        Set-EnvKey -Path $collectorEnv -Key 'COLLECTOR_PORT' -Value "$($script:ChosenCollectorPort)"
    }
    # Collector port is also read by server when talking to collector
    Set-EnvKey -Path $serverEnv -Key 'COLLECTOR_PORT' -Value "$($script:ChosenCollectorPort)"

    New-Item -ItemType Directory -Force -Path $storageDir | Out-Null
    Save-ChosenPorts

    Write-Log "Configured SERVER_PORT=$($script:ChosenServerPort) COLLECTOR_PORT=$($script:ChosenCollectorPort)"
    Write-Log 'Edit server\.env before production: JWT_SECRET, SIG_KEY, SIG_SALT, LLM_PROVIDER, API keys' 'WARN'
}

function Install-Dependencies {
    Write-Log 'Installing dependencies (server, collector, frontend)' 'STEP'
    foreach ($dir in @('server', 'collector', 'frontend')) {
        Invoke-Logged -WorkDir (Join-Path $InstallDir $dir) -Command @('yarn')
    }
}

function Build-AndPublishFrontend {
    Write-Log 'Building frontend' 'STEP'
    Invoke-Logged -WorkDir (Join-Path $InstallDir 'frontend') -Command @('yarn', 'build')

    $dist = Join-Path $InstallDir 'frontend\dist'
    $public = Join-Path $InstallDir 'server\public'
    Write-Log 'Copying frontend/dist to server/public' 'STEP'
    if (Test-Path $public) { Remove-Item $public -Recurse -Force }
    Copy-Item $dist $public -Recurse
}

function Invoke-DatabaseMigrations {
    Write-Log 'Running Prisma generate and migrate deploy' 'STEP'
    $serverDir = Join-Path $InstallDir 'server'
    Invoke-Logged -WorkDir $serverDir -Command @('npx', 'prisma', 'generate', '--schema=./prisma/schema.prisma')
    Invoke-Logged -WorkDir $serverDir -Command @('npx', 'prisma', 'migrate', 'deploy', '--schema=./prisma/schema.prisma')
}

function Add-FirewallRule {
    Write-Log "Opening Windows Firewall for AccelaNova TCP $($script:ChosenServerPort) only (not 80/443)" 'STEP'
    if (@(80, 443) -contains $script:ChosenServerPort) {
        Write-Log 'Refusing to open firewall for 80/443 unless you set SERVER_PORT to a non-privileged app port' 'ERROR'
        throw 'EXPOSE_FIREWALL will not open 80 or 443. Put IIS/nginx on 80/443 and AccelaNova on 3001+.'
    }
    $ruleName = "Accelanova HTTP $($script:ChosenServerPort)"
    $existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Log 'Firewall rule already exists'
        return
    }
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $script:ChosenServerPort | Out-Null
    Write-Log "Firewall rule added for port $($script:ChosenServerPort)"
}

function Start-AccelanovaServices {
    Write-Log 'Starting AccelaNova server and collector' 'STEP'
    Read-SavedPorts

    if ($script:Flags.InstallAsService -and (Test-Path $NssmPath)) {
        $serverSvc = "$ServiceName-Server"
        if (Get-Service -Name $serverSvc -ErrorAction SilentlyContinue) {
            Start-Service $serverSvc
            Start-Service "$ServiceName-Collector"
            Write-Log "Started Windows services $ServiceName-Server and $ServiceName-Collector"
            return
        }
        Write-Log 'Windows services not registered. Set InstallAsService during install.' 'WARN'
    }

    Stop-AccelanovaProcesses

    $serverLog = Join-Path $LogDir 'server.log'
    $collectorLog = Join-Path $LogDir 'collector.log'

    $serverArgs = "/c set NODE_ENV=production&& set SERVER_PORT=$($script:ChosenServerPort)&& set COLLECTOR_PORT=$($script:ChosenCollectorPort)&& node index.js >> `"$serverLog`" 2>&1"
    Start-Process -FilePath 'cmd.exe' -ArgumentList $serverArgs -WorkingDirectory (Join-Path $InstallDir 'server') -WindowStyle Hidden

    $collectorArgs = "/c set NODE_ENV=production&& set COLLECTOR_PORT=$($script:ChosenCollectorPort)&& node index.js >> `"$collectorLog`" 2>&1"
    Start-Process -FilePath 'cmd.exe' -ArgumentList $collectorArgs -WorkingDirectory (Join-Path $InstallDir 'collector') -WindowStyle Hidden

    Start-Sleep -Seconds 3
    Write-Log "Server log: $serverLog"
    Write-Log "Collector log: $collectorLog"
    Write-Log "App URL: http://localhost:$($script:ChosenServerPort)"
}

function Register-WindowsServices {
    Write-Log 'Registering Windows services via NSSM' 'STEP'
    if (-not (Test-Path $NssmPath)) {
        throw "NSSM not found at $NssmPath. Download from https://nssm.cc/"
    }

    Stop-AccelanovaProcesses

    $pairs = @(
        @{ Name = "$ServiceName-Server"; Dir = 'server'; Log = 'server.log'; Title = "$ServiceDisplay (Server)"; Extra = "set SERVER_PORT=$($script:ChosenServerPort)&& set COLLECTOR_PORT=$($script:ChosenCollectorPort)&&" },
        @{ Name = "$ServiceName-Collector"; Dir = 'collector'; Log = 'collector.log'; Title = "$ServiceDisplay (Collector)"; Extra = "set COLLECTOR_PORT=$($script:ChosenCollectorPort)&&" }
    )

    foreach ($svc in $pairs) {
        $logPath = Join-Path $LogDir $svc.Log
        $workDir = Join-Path $InstallDir $svc.Dir
        $appArgs = "/c $($svc.Extra) set NODE_ENV=production&& node index.js"

        & $NssmPath install $svc.Name 'cmd.exe' $appArgs 2>&1 | Tee-Object -FilePath $LogFile -Append | Out-Null
        & $NssmPath set $svc.Name AppDirectory $workDir 2>&1 | Out-Null
        & $NssmPath set $svc.Name DisplayName $svc.Title 2>&1 | Out-Null
        & $NssmPath set $svc.Name Start SERVICE_AUTO_START 2>&1 | Out-Null
        & $NssmPath set $svc.Name AppStdout $logPath 2>&1 | Out-Null
        & $NssmPath set $svc.Name AppStderr $logPath 2>&1 | Out-Null
        Start-Service $svc.Name
    }

    Write-Log "Registered and started $ServiceName-Server and $ServiceName-Collector"
}

# -----------------------------------------------------------------------------
Write-Host ''
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host '   AccelaNova - Windows VPS Installer' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ''
Write-Log "Mode: $Mode"
Write-Log "Install dir: $InstallDir"
Write-Log "Log file: $LogFile"

try {
    $listenMap = Show-VpsOccupancyReport

    if ($Mode -eq 'scan') {
        Write-Log 'Scan-only complete (no changes made)' 'STEP'
        exit 0
    }

    if ($Mode -in @('install', 'update', 'start')) {
        Resolve-PortsSafely -ListenMap $listenMap
        Write-Log "Using SERVER_PORT=$($script:ChosenServerPort) COLLECTOR_PORT=$($script:ChosenCollectorPort)"
        Confirm-ContinueIfBusy
    }
    elseif ($Mode -eq 'stop') {
        if ($script:OtherAppsFound -and -not $script:Flags.Yes) {
            Write-Host 'Other apps detected. stop mode only kills AccelaNova processes under InstallDir.' -ForegroundColor Yellow
            $answer = Read-Host 'Continue with AccelaNova-only stop? [Y/N]'
            if ($answer -notmatch '^(Y|y|Yes|yes)$') {
                throw 'Aborted by operator.'
            }
        }
    }

    switch ($Mode) {
        'stop' {
            Stop-AccelanovaProcesses
            Write-Log 'Stopped AccelaNova node processes under InstallDir (if any)'
            exit 0
        }
        'start' {
            if (-not (Test-Path (Join-Path $InstallDir 'server\index.js'))) {
                throw "Install not found at $InstallDir. Run install first."
            }
            Start-AccelanovaServices
            exit 0
        }
        'update' {
            Test-Prerequisites
            Update-Repository
            Initialize-EnvFiles
            if ($script:Flags.InstallDeps) { Install-Dependencies }
            if ($script:Flags.BuildFrontend) { Build-AndPublishFrontend }
            if ($script:Flags.RunMigrations) { Invoke-DatabaseMigrations }
            if ($script:Flags.ExposeFirewall) { Add-FirewallRule }
            if ($script:Flags.InstallAsService) { Register-WindowsServices }
            elseif ($script:Flags.StartAfterInstall) { Start-AccelanovaServices }
        }
        default {
            # install
            Test-Prerequisites
            Initialize-Repository
            Initialize-EnvFiles
            if ($script:Flags.InstallDeps) { Install-Dependencies }
            if ($script:Flags.BuildFrontend) { Build-AndPublishFrontend }
            if ($script:Flags.RunMigrations) { Invoke-DatabaseMigrations }
            if ($script:Flags.ExposeFirewall) { Add-FirewallRule }
            if ($script:Flags.InstallAsService) { Register-WindowsServices }
            elseif ($script:Flags.StartAfterInstall) { Start-AccelanovaServices }
        }
    }

    Write-Log 'Done' 'STEP'
    Write-Log "Accelanova should be available at http://localhost:$($script:ChosenServerPort)"
    Write-Log 'Review server/.env for LLM keys, JWT_SECRET, and STORAGE_DIR.'
    if ($script:PortConflictResolved) {
        Write-Log "Ports were remapped. Chosen ports saved to $InstallDir\logs\chosen-ports.json" 'WARN'
    }
    exit 0
}
catch {
    Write-Log $_.Exception.Message 'ERROR'
    Write-Host ''
    Write-Host "Installer failed. See log: $LogFile" -ForegroundColor Red
    exit 1
}
